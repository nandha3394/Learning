package com.spring.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect {
	@Before("callAllGetters()")
	public void LoggingAdvice() {
      System.out.println("Logging advice called");
	}
	
	@After("callAllGetters()")
	public void LoggingAdviceSecond(JoinPoint joinpoint) {
      System.out.println("Entering the method " + joinpoint.getSignature().getName());
	}
	
	@Pointcut("within(com.spring.jdbc.*)")
	public void callAllGetters(){};
}
