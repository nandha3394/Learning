package com.spring.main;

public interface AddressInterface {
  void printAddress();
}
