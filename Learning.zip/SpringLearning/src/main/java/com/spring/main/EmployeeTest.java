package com.spring.main;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.spring.jdbc.DBConnection;
import com.spring.pojo.Employee;

public class EmployeeTest {
   public static void main(String args[]){
	   /*Employee emp1 = new Employee();
	   emp1.setId(1);
	   emp1.setName("nandha");
	   System.out.println(emp1);*/
	   /*Resource resource = new ClassPathResource("employeebeanfactory.xml");  
	   BeanFactory factory = new XmlBeanFactory(resource);
	   Employee emp1 = (Employee)factory.getBean("emp1");*/
	   AbstractApplicationContext context = new ClassPathXmlApplicationContext("employeebeanfactory.xml");
	   context.registerShutdownHook();
	   DBConnection dbConnection = context.getBean("dbconnection", DBConnection.class);
	   //dbConnection.Connector();
	   dbConnection.getEmployees();
	   /*Employee emp1 = (Employee) context.getBean("emp1");
	   System.out.println("Employee city is " + emp1.getAddress().getCity());*/
	   /*ApplicationContext context =  new AnnotationConfigApplicationContext(EmployeeConfig.class);  
	   Employee emp1 = (Employee)context.getBean("employee");*/
	   /*System.out.println(emp1);*/
   }
}
