package com.spring.pojo;

import org.springframework.stereotype.Component;

import com.spring.main.AddressInterface;

/*@Component*/
public class Address1 /*implements AddressInterface*/ {
  private String city;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Address1 [city=" + city + "]";
	}

	/*@Override*/
	public void printAddress() {
		System.out.println("Inside Address1");	
	}
  
}
