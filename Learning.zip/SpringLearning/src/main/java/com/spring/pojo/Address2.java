package com.spring.pojo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.spring.main.AddressInterface;

@Component
@Primary
public class Address2 implements AddressInterface {
  private String brand;

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Address2 [brand=" + brand + "]";
	}

	@Override
	public void printAddress() {
		System.out.println("Inside Address2");	
	}
  
}
