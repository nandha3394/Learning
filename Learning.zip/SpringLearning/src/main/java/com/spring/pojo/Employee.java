package com.spring.pojo;

import javax.annotation.Resource;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import com.spring.main.*;

@Component
public class Employee /*implements ApplicationContextAware,InitializingBean,DisposableBean*/{
	String name;
	/*@Resource*/
	/*@Qualifier("address1")*/
	private Address1 address;
	ApplicationContext context = null;
	
	public Address1 getAddress() {
		return address;
	}

	public void setAddress(Address1 address) {
		this.address = address;
	}

	public Employee(String name) {
		super();
		this.name = name;
		//this.id = id;
	}

	int id;

	public Employee() {
		System.out.println("constructor invoked");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void objectInitialized(){
		System.out.println("Object Initialized");
	}
	
	public void objectDestroyed(){
		System.out.println("Object Destroyed");
	}
	
	public void emp(){
		System.out.println("Hey my name is cola");
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]" + ", address=" + address;
	}

	/*@Override
	public void setApplicationContext(ApplicationContext context)
			throws BeansException {
		this.context = context;
		System.out.println("Inside setApplicationContext");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Inside initializebean afterPropertiesSet method");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("Inside Disposablebean destroy method");
	}*/
}
