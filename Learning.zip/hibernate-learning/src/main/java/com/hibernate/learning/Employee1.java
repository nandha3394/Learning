package com.hibernate.learning;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.CascadeType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.*;
import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;

// Annotation Java Bean
 @Entity
 @Cacheable
 @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
 @Table(name="Employee", 
 uniqueConstraints={@UniqueConstraint(columnNames={"ID"})})
public class Employee1 {
	 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID", nullable = false, unique = true, length = 11)
	private int id;
	
	@Column(name = "NAME", length = 20, nullable = true)
	private String name;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="employee")
	List<AddressTO> addresses = new ArrayList<AddressTO>();

	public int getId() {
		return id;
	}

	public Employee1(String name, List<AddressTO> addresses) {
		this.name = name;
		this.addresses = addresses;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<AddressTO> getAddresses() {
		return addresses;
	}

	public void setAddress(List<AddressTO> addresses) {
		this.addresses = addresses;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
