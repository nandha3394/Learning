package com.hibernate.learning;

import java.util.*;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.omg.CosNaming.NamingContextExtPackage.AddressHelper;

import com.hibernate.learning.Employee;

public class HibernateMain {
	
	public static void main(String[] args){
		List<AddressTO> addresses = new ArrayList<AddressTO>();
		addresses.add(new AddressTO("Saravanampatti"));
		addresses.add(new AddressTO("Hopes College"));
		addresses.add(new AddressTO("Cheran Managar"));
		Employee1 e1 = new Employee1("Prasanth", addresses);
		Session session = HibernateUtil.getSessionAnnotationFactory().openSession();
		session.beginTransaction();
		session.save(e1);
		//session.save(address);
		/*Criteria cr = session.createCriteria(Employee1.class, "employee")
				.createAlias("employee.addresses", "address");
		List results = cr.list();
		Iterator itr = results.iterator();
		while(itr.hasNext()){
			Employee1 emp1 = (Employee1)itr.next();
			System.out.println(emp1.getName());
		}*/
		
		/*Employee1 e = (Employee1) session.load(Employee1.class, 1);
		System.out.println(e.getName());*/
		session.getTransaction().commit();
		session.close();
		
		/*Session session1 = HibernateUtil.getSessionAnnotationFactory().openSession();
		session1.beginTransaction();
		Employee1 emp = (Employee1) session1.load(Employee1.class, 1);
		System.out.println(emp.getName());
		session1.getTransaction().commit();
		session1.close();*/
		HibernateUtil.closeSessionFactory();
	}

}
